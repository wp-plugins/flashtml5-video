1) Install the plugin
2) Click on the Admin panel for useage information
